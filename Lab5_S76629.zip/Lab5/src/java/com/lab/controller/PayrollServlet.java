package com.lab.controller;

import com.lab.bean.Employee;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PayrollServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<Employee> list = new ArrayList<>();
        
        // Populate with at least 5 objects
        Employee e1 = new Employee(); e1.setEmpId("E001"); e1.setName("Varma"); e1.setDepartment("IT"); e1.setBasicSalary(4500.0);
        Employee e2 = new Employee(); e2.setEmpId("E002"); e2.setName("Siti"); e2.setDepartment("HR"); e2.setBasicSalary(2800.0);
        Employee e3 = new Employee(); e3.setEmpId("E003"); e3.setName("Ravi"); e3.setDepartment("Finance"); e3.setBasicSalary(3200.0);
        Employee e4 = new Employee(); e4.setEmpId("E004"); e4.setName("John"); e4.setDepartment("Sales"); e4.setBasicSalary(2500.0);
        Employee e5 = new Employee(); e5.setEmpId("E005"); e5.setName("Amina"); e5.setDepartment("IT"); e5.setBasicSalary(5000.0);

        list.add(e1); list.add(e2); list.add(e3); list.add(e4); list.add(e5);

        // Share list to JSP
        request.setAttribute("employeeList", list);
        
        // Forward to view
        request.getRequestDispatcher("payroll_view.jsp").forward(request, response);
    }
}