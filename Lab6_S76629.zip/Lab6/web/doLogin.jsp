<%-- 
    Document   : doLogin
    Created on : May 12, 2026, 3:51:24 PM
    Author     : Jeeva
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<%
    String user = request.getParameter("username");
    String pass = request.getParameter("password");

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/CF3107", "root", "admin");
        
        PreparedStatement ps = conn.prepareStatement("SELECT * FROM userprofile WHERE username=? AND password=?");
        ps.setString(1, user);
        ps.setString(2, pass);
        
        ResultSet rs = ps.executeQuery();
        
        if(rs.next()) {
            // Successful validation: store data in session and redirect to main.jsp
            session.setAttribute("user", rs.getString("username"));
            session.setAttribute("fname", rs.getString("firstname"));
            session.setAttribute("lname", rs.getString("lastname"));
            response.sendRedirect("main.jsp");
        } else {
            // Failed validation: redirect back to login.jsp 
            response.sendRedirect("login.jsp?msg=Invalid username or password..!");
        }
        conn.close();
    } catch(Exception e) { out.println("Error: " + e.getMessage()); }
%>