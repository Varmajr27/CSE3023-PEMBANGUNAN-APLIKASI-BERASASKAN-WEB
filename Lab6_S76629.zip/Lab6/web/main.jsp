<%-- 
    Document   : main
    Created on : May 12, 2026, 3:51:43 PM
    Author     : Jeeva
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<body>
    <h2>Welcome to the System</h2>
    <p><b>Username:</b> <%=session.getAttribute("user")%></p>
    <p><b>First Name:</b> <%=session.getAttribute("fname")%></p>
    <p><b>Last Name:</b> <%=session.getAttribute("lname")%></p>
    <br>
    <a href="login.jsp">Logout</a>
</body>
</html>