<%-- 
    Document   : processUser
    Created on : May 12, 2026, 3:50:22 PM
    Author     : Jeeva
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>
<%
    String username = request.getParameter("username");
    String pass = request.getParameter("password");
    String fname = request.getParameter("firstname");
    String lname = request.getParameter("lastname");

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/CF3107", "root", "admin");
        
        PreparedStatement ps = conn.prepareStatement("INSERT INTO userprofile VALUES(?,?,?,?)");
        ps.setString(1, username);
        ps.setString(2, pass);
        ps.setString(3, fname);
        ps.setString(4, lname);
        
        ps.executeUpdate();
        out.println("Registration successful! <a href='login.jsp'>Login here</a>");
        conn.close();
    } catch(Exception e) { out.println("Error: " + e.getMessage()); }
%>