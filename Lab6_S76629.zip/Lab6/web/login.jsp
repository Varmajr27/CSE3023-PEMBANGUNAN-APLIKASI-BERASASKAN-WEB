<%-- 
    Document   : login
    Created on : May 12, 2026, 3:51:05 PM
    Author     : Jeeva
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<body>
    <h2>Login</h2>
    <%-- Display error message if redirected from doLogin.jsp --%>
    <p style="color:red;"><%=(request.getParameter("msg") != null) ? request.getParameter("msg") : "" %></p>
    
    <form action="doLogin.jsp" method="POST">
        Username: <input type="text" name="username" required><br><br>
        Password: <input type="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>