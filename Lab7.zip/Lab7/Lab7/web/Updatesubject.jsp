<%-- 
    Document   : Updatesubject
    Created on : May 19, 2026, 10:19:57 PM
    Author     : Jeeva
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<%@page import="com.lab.bean.SubjectBean"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Subject</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 40px; }
        .form-box {
            max-width: 480px; margin: auto; background: white;
            padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        h2 { color: #2c3e50; margin-top: 0; }
        label { display: block; margin-bottom: 6px; font-weight: bold; color: #555; }
        input[type=text] {
            width: 100%; padding: 9px 12px; border: 1px solid #ccc;
            border-radius: 4px; font-size: 14px; margin-bottom: 18px; box-sizing: border-box;
        }
        .btn-update {
            background: #f39c12; color: white; padding: 10px 24px;
            border: none; border-radius: 4px; font-size: 14px;
            font-weight: bold; cursor: pointer; width: 100%;
        }
        .btn-update:hover { background: #d68910; }
        .back-link { display: block; margin-top: 14px; text-align: center;
                     color: #2c3e50; text-decoration: none; font-size: 13px; }
    </style>
</head>
<body>
<%
    // Session check
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect("login.html");
        return;
    }
    SubjectBean subject = (SubjectBean) request.getAttribute("subject");
    if (subject == null) {
        response.sendRedirect("SubjectServlet?action=view");
        return;
    }
%>

<div class="form-box">
    <h2>Update Subject</h2>
    <p style="color:#777; margin-top:-10px; margin-bottom:20px;">
        Editing for: <strong><%= user.getMatricNo() %></strong>
    </p>

    <form action="SubjectServlet" method="POST">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<%= subject.getId() %>">

        <label>Subject Code</label>
        <input type="text" name="subjectCode" value="<%= subject.getSubjectCode() %>" required>

        <label>Subject Name</label>
        <input type="text" name="subjectName" value="<%= subject.getSubjectName() %>" required>

        <button type="submit" class="btn-update">Save Changes</button>
    </form>

    <a href="SubjectServlet?action=view" class="back-link">← Back to My Subjects</a>
</div>

</body>
</html>
