<%-- 
    Document   : Viewsubject
    Created on : May 19, 2026, 10:20:25 PM
    Author     : Jeeva
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<%@page import="com.lab.bean.SubjectBean"%>
<%@page import="java.util.List"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Subjects</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: auto; }
        h2 { color: #2c3e50; }
        .welcome-bar {
            background: #2c3e50; color: white; padding: 12px 20px;
            border-radius: 6px; margin-bottom: 20px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .welcome-bar a { color: #f39c12; text-decoration: none; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; background: white;
                border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        th { background: #2c3e50; color: white; padding: 12px; text-align: left; }
        td { padding: 12px; border-bottom: 1px solid #eee; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #f0f4ff; }
        .btn { padding: 6px 14px; border-radius: 4px; text-decoration: none;
               font-size: 13px; font-weight: bold; border: none; cursor: pointer; }
        .btn-edit { background: #f39c12; color: white; }
        .btn-delete { background: #e74c3c; color: white; }
        .add-form { background: white; padding: 20px; border-radius: 8px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 24px; }
        .add-form h3 { margin-top: 0; color: #2c3e50; }
        .add-form input[type=text] {
            padding: 8px 12px; border: 1px solid #ccc; border-radius: 4px;
            width: 220px; margin-right: 8px; font-size: 14px;
        }
        .btn-add { background: #27ae60; color: white; padding: 9px 20px; }
        .no-data { text-align: center; padding: 30px; color: #999; }
    </style>
</head>
<body>
<%
    // Session check
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect("login.html");
        return;
    }
    List<SubjectBean> subjectList = (List<SubjectBean>) request.getAttribute("subjectList");
%>

<div class="container">

    <!-- Top bar -->
    <div class="welcome-bar">
        <span>Welcome, <strong><%= user.getFullname() %></strong> | <%= user.getMatricNo() %></span>
        <a href="UserServlet?action=logout">Logout</a>
    </div>

    <h2>My Registered Subjects</h2>

    <!-- ADD SUBJECT FORM (CREATE) -->
    <div class="add-form">
        <h3>Register New Subject</h3>
        <form action="SubjectServlet" method="POST">
            <input type="hidden" name="action" value="add">
            <input type="text" name="subjectCode" placeholder="Subject Code (e.g. CSA3023)" required>
            <input type="text" name="subjectName" placeholder="Subject Name" required>
            <button type="submit" class="btn btn-add">+ Add Subject</button>
        </form>
    </div>

    <!-- VIEW SUBJECTS TABLE (READ) -->
    <table>
        <tr>
            <th>#</th>
            <th>Subject Code</th>
            <th>Subject Name</th>
            <th>Actions</th>
        </tr>
        <%
            if (subjectList == null || subjectList.isEmpty()) {
        %>
        <tr><td colspan="4" class="no-data">No subjects registered yet.</td></tr>
        <%
            } else {
                int count = 1;
                for (SubjectBean s : subjectList) {
        %>
        <tr>
            <td><%= count++ %></td>
            <td><%= s.getSubjectCode() %></td>
            <td><%= s.getSubjectName() %></td>
            <td>
                <a href="SubjectServlet?action=editForm&id=<%= s.getId() %>" class="btn btn-edit">Edit</a>
                &nbsp;
                <a href="SubjectServlet?action=delete&id=<%= s.getId() %>"
                   onclick="return confirm('Delete <%= s.getSubjectCode() %>?');"
                   class="btn btn-delete">Delete</a>
            </td>
        </tr>
        <%
                }
            }
        %>
    </table>

</div>
</body>
</html>
