/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab.dao;

import com.lab.bean.StudentBean;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Base64;

/**
 *
 * @author Jeeva
 */

public class StudentDAO {
    
    // Establishes connection to the MySQL database
    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3307/lab7_db", "root", "admin");
    }

    // --- REGISTER LOGIC ---
    public boolean registerStudent(StudentBean student, InputStream imageStream) {
        String sql = "INSERT INTO students (matric_no, password, fullname, profile_image) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, student.getMatricNo());
            pstmt.setString(2, student.getPassword());
            pstmt.setString(3, student.getFullname());
            pstmt.setBlob(4, imageStream); // Stores image as binary data (BLOB)
            
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // --- LOGIN LOGIC ---
    public StudentBean loginStudent(String matricNo, String password) {
        StudentBean student = null;
        String sql = "SELECT * FROM students WHERE matric_no = ? AND password = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, matricNo);
            pstmt.setString(2, password);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    student = new StudentBean();
                    student.setMatricNo(rs.getString("matric_no"));
                    student.setFullname(rs.getString("fullname"));
                    
                    // Fetch binary BLOB data and encode it to a Base64 String for the view
                    Blob blob = rs.getBlob("profile_image");
                    if (blob != null) {
                        try (InputStream inputStream = blob.getBinaryStream();
                             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
                            
                            byte[] buffer = new byte[4096];
                            int bytesRead;
                            while ((bytesRead = inputStream.read(buffer)) != -1) {
                                outputStream.write(buffer, 0, bytesRead);
                            }
                            
                            byte[] imageBytes = outputStream.toByteArray();
                            student.setBase64Image(Base64.getEncoder().encodeToString(imageBytes));
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return student; // Returns null if login credentials fail
    }

    // --- DELETE LOGIC ---
    public boolean deleteStudent(String matricNo) {
        String sql = "DELETE FROM students WHERE matric_no = ?";
        try (Connection conn = getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, matricNo);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}