/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab.controller;

import com.lab.bean.StudentBean;
import com.lab.dao.StudentDAO;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

/**
 *
 * @author Jeeva
 */

@MultipartConfig(maxFileSize = 16177215) // Sets max file size to roughly 16MB for image uploads
public class UserServlet extends HttpServlet {
    private StudentDAO studentDAO = new StudentDAO(); // Reference to database logic

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8"); //
        
        // Read the hidden parameter to decide which action to execute
        String action = request.getParameter("action"); //

        // 1. HANDLE REGISTRATION
        if ("register".equals(action)) { //
            StudentBean newStudent = new StudentBean(); //
            newStudent.setMatricNo(request.getParameter("matricNo")); //
            newStudent.setFullname(request.getParameter("fullname")); //
            newStudent.setPassword(request.getParameter("password")); //

            InputStream inputStream = null; //
            Part filePart = request.getPart("profileImage"); // Captures the multipart form file
            if (filePart != null && filePart.getSize() > 0) { //
                inputStream = filePart.getInputStream(); // Extracts binary data stream
            }

            boolean isSuccess = studentDAO.registerStudent(newStudent, inputStream); //
            if (isSuccess) { //
                response.getWriter().println("Registration Successful! <a href='login.html'>Login here</a>"); //
            } else { //
                response.getWriter().println("Registration Failed!"); //
            }
        } 
        
        // 2. HANDLE LOGIN
        else if ("login".equals(action)) { //
            String matric = request.getParameter("matricNo"); //
            String pass = request.getParameter("password"); //

            StudentBean student = studentDAO.loginStudent(matric, pass); //
            if (student != null) { //
                // Login successful: Store the entire bean inside the temporary server session
                HttpSession session = request.getSession(); //
                session.setAttribute("loggedUser", student); //
                response.sendRedirect("dashboard.jsp"); // Redirects securely to the main dashboard view
            } else { //
                response.getWriter().println("Invalid Credentials! <a href='login.html'>Try Again</a>"); //
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html; charset=UTF-8");
        
        String action = request.getParameter("action"); //
        HttpSession session = request.getSession(false); // Fetch session if it exists; do not create a new one

        // 3. HANDLE LOGOUT
        if ("logout".equals(action)) { //
            if (session != null) { //
                session.invalidate(); // Destroy session securely to clear user authentication cache
            }
            response.sendRedirect("login.html"); // Redirect back to general login portal
        } 
        
        // 4. HANDLE DELETE ACCOUNT
        else if ("delete".equals(action)) { //
            if (session != null && session.getAttribute("loggedUser") != null) { //
                StudentBean user = (StudentBean) session.getAttribute("loggedUser"); //
                studentDAO.deleteStudent(user.getMatricNo()); //
                session.invalidate(); // Clear out active user track tokens completely
            }
            response.sendRedirect("register.html"); // Bounce back to register view
        }
    } // Closes doGet method
} // Closes Class definition