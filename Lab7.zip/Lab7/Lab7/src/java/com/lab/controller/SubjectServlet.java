/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lab.controller;

import com.lab.bean.StudentBean;
import com.lab.bean.SubjectBean;
import com.lab.dao.SubjectDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Jeeva
 */

public class SubjectServlet extends HttpServlet {

    private SubjectDAO subjectDAO = new SubjectDAO();

    // GET: handles view, edit form, and delete
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        // Session check - must be logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.html");
            return;
        }

        StudentBean loggedUser = (StudentBean) session.getAttribute("loggedUser");
        String matricNo = loggedUser.getMatricNo();
        String action = request.getParameter("action");

        if (action == null) {
            action = "view";
        }

        if ("view".equals(action)) {
            // READ: Fetch all subjects for this student and forward to viewSubjects.jsp
            List<SubjectBean> subjects = subjectDAO.getSubjectsByMatric(matricNo);
            request.setAttribute("subjectList", subjects);
            request.getRequestDispatcher("/Viewsubject.jsp").forward(request, response);

        } else if ("editForm".equals(action)) {
            // Load subject data into the update form
            int id = Integer.parseInt(request.getParameter("id"));
            SubjectBean subject = subjectDAO.getSubjectById(id);
            request.setAttribute("subject", subject);
            request.getRequestDispatcher("/Updatesubject.jsp").forward(request, response);

        } else if ("delete".equals(action)) {
            // DELETE: Remove subject and redirect back to view
            int id = Integer.parseInt(request.getParameter("id"));
            subjectDAO.deleteSubject(id, matricNo);
            response.sendRedirect("SubjectServlet?action=view");
        }
    }

    // POST: handles add and update submissions
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        // Session check
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loggedUser") == null) {
            response.sendRedirect("login.html");
            return;
        }

        StudentBean loggedUser = (StudentBean) session.getAttribute("loggedUser");
        String matricNo = loggedUser.getMatricNo();
        String action = request.getParameter("action");

        if ("add".equals(action)) {
            // CREATE: Register a new subject
            SubjectBean subject = new SubjectBean();
            subject.setMatricNo(matricNo);
            subject.setSubjectCode(request.getParameter("subjectCode"));
            subject.setSubjectName(request.getParameter("subjectName"));

            subjectDAO.addSubject(subject);
            response.sendRedirect("SubjectServlet?action=view");

        } else if ("update".equals(action)) {
            // UPDATE: Save edited subject
            SubjectBean subject = new SubjectBean();
            subject.setId(Integer.parseInt(request.getParameter("id")));
            subject.setMatricNo(matricNo);
            subject.setSubjectCode(request.getParameter("subjectCode"));
            subject.setSubjectName(request.getParameter("subjectName"));

            subjectDAO.updateSubject(subject);
            response.sendRedirect("SubjectServlet?action=view");
        }
    }
}